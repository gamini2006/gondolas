jQuery(document).ready(function($){
    $('#btn_bg_color').wpColorPicker();
    $('#btn_color').wpColorPicker();
});